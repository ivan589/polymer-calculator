core-layout
===========

## DEPRECATED (in favor of layout attributes)
