core-tests
==========

Tests for polymer elements. The tooling is at https://github.com/polymer/polymer-test-tools
