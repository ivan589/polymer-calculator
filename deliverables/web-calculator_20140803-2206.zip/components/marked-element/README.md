marked-element
==============

See the [component page](http://polymer.github.io/marked-element) for more information.