core-animated-pages
===================

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-animated-pages) for more information.
