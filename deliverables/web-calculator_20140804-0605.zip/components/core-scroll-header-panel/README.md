core-scroll-header-panel
========================

See the [component page](http://polymer-project.org/docs/elements/core-elements.html#core-scroll-header-panel) for more information.
