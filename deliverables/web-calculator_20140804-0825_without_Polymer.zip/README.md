web-calculator
=================

To run this locally you can use Python simple server:

<ol>
	<li><code>cd polymer-calculator</code></li>
	<li><code>python -m SimpleHTTPServer</code></li>
</ol>
