web-calculator
=================

To run this locally you can use Python simple server. <br />
Polymer depencies managed with bower.

<ol>
	<li><code>git clone `url`</code></li>
	<li><code>cd web-calculator</code></li>
	<li><code>bower install</code></li>
	<li><code>python -m SimpleHTTPServer</code></li>
</ol>
